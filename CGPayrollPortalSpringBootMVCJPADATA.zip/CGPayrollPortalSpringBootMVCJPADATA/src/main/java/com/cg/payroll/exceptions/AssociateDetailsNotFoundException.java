package com.cg.payroll.exceptions;

public class AssociateDetailsNotFoundException extends Exception {

	public AssociateDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AssociateDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public AssociateDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
	
	}

	public AssociateDetailsNotFoundException(String message) {
		super(message);
		
	}
	public AssociateDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
