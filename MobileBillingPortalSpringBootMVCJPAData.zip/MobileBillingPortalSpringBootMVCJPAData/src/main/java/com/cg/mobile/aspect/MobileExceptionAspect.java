package com.cg.mobile.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

@ControllerAdvice
public class MobileExceptionAspect {

	@ExceptionHandler(BillDetailsNotFoundException.class)
	public ModelAndView  handelBillDetailsNotFoundException(Exception e) {
		return new ModelAndView("findAssociateDetails", "errorMessage",e.getMessage());
	}
	
	@ExceptionHandler(CustomerDetailsNotFoundException.class)
	public ModelAndView  handelCustomerDetailsNotFoundException(Exception e) {
		return new ModelAndView("findAssociateDetails", "errorMessage",e.getMessage());
	}

	@ExceptionHandler(InvalidBillMonthException.class)
	public ModelAndView  handelInvalidBillMonthException(Exception e) {
		return new ModelAndView("findAssociateDetails", "errorMessage",e.getMessage());
	}

	@ExceptionHandler(PlanDetailsNotFoundException.class)
	public ModelAndView  handelPlanDetailsNotFoundException(Exception e) {
		return new ModelAndView("findAssociateDetails", "errorMessage",e.getMessage());
	}

	@ExceptionHandler(PostpaidAccountNotFoundException.class)
	public ModelAndView  handelPostpaidAccountNotFoundException(Exception e) {
		return new ModelAndView("findAssociateDetails", "errorMessage",e.getMessage());
	}


}
