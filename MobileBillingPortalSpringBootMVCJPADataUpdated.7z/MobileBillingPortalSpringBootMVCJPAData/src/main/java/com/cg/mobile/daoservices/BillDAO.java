package com.cg.mobile.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.mobile.beans.Bill;

public interface BillDAO extends JpaRepository<Bill, Integer>{
	 
}
