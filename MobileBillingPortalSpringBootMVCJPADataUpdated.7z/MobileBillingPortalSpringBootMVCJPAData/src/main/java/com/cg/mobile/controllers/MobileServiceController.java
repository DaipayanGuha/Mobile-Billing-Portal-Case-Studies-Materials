package com.cg.mobile.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobile.beans.Customer;
import com.cg.mobile.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobile.services.BillingServices;

@Controller
public class MobileServiceController {

	@Autowired
	BillingServices billingServices;

	@RequestMapping("/registerCustomer")
	public ModelAndView registerAssociate(@Valid @ModelAttribute Customer customer,BindingResult result ) throws CustomerDetailsNotFoundException {
		if(result.hasErrors()) return new ModelAndView("AddNewRegisterPage");
		customer=billingServices.getCustomerDetails(customer);
		return new ModelAndView("registrationSuccess", "customer", customer);
	}
}
