package com.cg.mobile.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.mobile.beans.Bill;
import com.cg.mobile.beans.Customer;
import com.cg.mobile.beans.Plan;
import com.cg.mobile.beans.PostpaidAccount;

@Controller
public class URIController {
	
	private Customer customer;
	private PostpaidAccount postpaidAccount;
	private Plan plan;
	private Bill bill;
	
	@RequestMapping( value= {  "/","index"})
	public String getIndexPage() {
		return "index";
	}
	
	@RequestMapping("/addCustomer")
	public  String getAddNewCustomerPage() {

		return "AddNewCustomerPage";
	}
	
	@RequestMapping("/addCustomer")
	public  String getDisplayCustomerDetailsPage() {

		return "DisplayCustomerDetailsPage";
	}
	
}
