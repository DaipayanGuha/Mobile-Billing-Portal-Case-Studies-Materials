package com.cg.mobile.daoservices;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.mobile.beans.Customer;
public interface CustomerDAO extends JpaRepository<Customer, Integer>{
	
	@Query(value="from Customer a wherea.billMonth=:")
	List<Customer>getAllAssociateByName(String name);
}
