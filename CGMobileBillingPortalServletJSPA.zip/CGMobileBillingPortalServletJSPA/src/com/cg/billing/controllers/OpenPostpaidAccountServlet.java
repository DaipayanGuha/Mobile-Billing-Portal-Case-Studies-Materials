package com.cg.billing.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;

/**
 * Servlet implementation class OpenPostpaidAccountServlet
 */
@WebServlet("/OpenPostpaidAccountServlet")
public class OpenPostpaidAccountServlet extends HttpServlet {
	private BillingServices services;
	public void init()throws ServletException{
		services=new BillingServicesImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher=null;
		int customerID=Integer.parseInt(request.getParameter("customerID"));
		int planID=Integer.parseInt(request.getParameter("planID"));
		try {
		long mobileNo=services.openPostpaidMobileAccount(customerID, planID);
		dispatcher=request.getRequestDispatcher("ResultOpenPostpaidAccount.jsp");
		request.setAttribute("mobileNo",mobileNo);
		dispatcher.forward(request, response);
		}catch(CustomerDetailsNotFoundException e) {dispatcher =request.getRequestDispatcher("Error.jsp");
		  request.setAttribute("error", "Customer ID not found");}
	      catch(PlanDetailsNotFoundException e) {dispatcher =request.getRequestDispatcher("Error.jsp");
	  	  request.setAttribute("error", "Plan ID not found");}
	}
	@Override
	public void destroy() {
		services=null;
	}
}