package com.cg.billing.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;

@WebServlet("/AddCustomerServlet")
public class AddCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BillingServices services;
	public void init()throws ServletException{
		services=new BillingServicesImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher=null;
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String emailID=request.getParameter("emailID"); 
		String dateOfBirth=request.getParameter("dateOfBirth");
		int homeAddressPinCode=Integer.parseInt(request.getParameter("homePinCode"));
		String homeAddressCity=request.getParameter("homeTown");
		String homeAddressState=request.getParameter("homeState");
		String billingAddressCity=request.getParameter("billingTown");
		String billingAddressState=request.getParameter("billingState");
		int billingAddressPinCode =Integer.parseInt(request.getParameter("billingPinCode"));
		int customerID=services.acceptCustomerDetails(firstName, lastName, emailID, dateOfBirth, billingAddressCity, billingAddressState, billingAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
		dispatcher=request.getRequestDispatcher("ResultAddNewCustomer.jsp");
		request.setAttribute("customerID",customerID);
		dispatcher.forward(request, response);
	}
	@Override
	public void destroy() {
		services=null;
	}
}