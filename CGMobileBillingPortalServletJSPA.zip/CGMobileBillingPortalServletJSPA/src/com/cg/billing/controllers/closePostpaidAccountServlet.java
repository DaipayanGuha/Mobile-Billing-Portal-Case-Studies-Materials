package com.cg.billing.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.BillingServicesImpl;

/**
 * Servlet implementation class closePostpaidAccountServlet
 */
@WebServlet("/closePostpaidAccountServlet")
public class closePostpaidAccountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private BillingServices services;
	public void init()throws ServletException{
		services=new BillingServicesImpl();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher=null;
		int customerID=Integer.parseInt(request.getParameter("customerID"));
		int mobileNo=Integer.parseInt(request.getParameter("mobileNo"));
		try {
		boolean closeAccount=services.closeCustomerPostPaidAccount(customerID, mobileNo);
		dispatcher=request.getRequestDispatcher("ResultChangePlan.jsp");
		request.setAttribute("changePlan","Account has been closed.");
		dispatcher.forward(request, response);
		}catch(CustomerDetailsNotFoundException e) {dispatcher =request.getRequestDispatcher("Error.jsp");
		  request.setAttribute("error", "Customer ID not found");}
		catch(PostpaidAccountNotFoundException e) {dispatcher =request.getRequestDispatcher("Error.jsp");
	  	  request.setAttribute("error", "Mobile Number not found");}
	}
	@Override
	public void destroy() {
		services=null;
	}
}